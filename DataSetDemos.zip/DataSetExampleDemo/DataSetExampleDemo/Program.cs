﻿using System.Data;

namespace DataSetExampleDemo
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Customer-Order DataSet");

            try
            {
                // Creating Customer Data Table
                DataTable Customer = new DataTable("Customer");

                // Adding Data Columns to the Customer Data Table
                DataColumn CustomerId = new DataColumn("ID", typeof(Int32));
                Customer.Columns.Add(CustomerId);
                DataColumn CustomerName = new DataColumn("Name", typeof(string));
                Customer.Columns.Add(CustomerName);
                DataColumn CustomerMobile = new DataColumn("Mobile", typeof(string));
                Customer.Columns.Add(CustomerMobile);

                //Adding Data Rows into Customer Data Table
                Customer.Rows.Add(101, "Anurag", "2233445566");
                Customer.Rows.Add(202, "Manoj", "1234567890");

                // Creating Orders Data Table
                DataTable Orders = new DataTable("Orders");

                // Adding Data Columns to the Orders Data Table
                DataColumn OrderId = new DataColumn("ID", typeof(System.Int32));
                Orders.Columns.Add(OrderId);
                DataColumn CustId = new DataColumn("CustomerId", typeof(Int32));
                Orders.Columns.Add(CustId);
                DataColumn OrderAmount = new DataColumn("Amount", typeof(int));
                Orders.Columns.Add(OrderAmount);

                //Adding Data Rows into Orders Data Table
                Orders.Rows.Add(10001, 101, 20000);
                Orders.Rows.Add(10002, 102, 30000);

                //Creating DataSet Object
                DataSet dataSet = new DataSet();

                //Adding DataTables into DataSet
                dataSet.Tables.Add(Customer);
                dataSet.Tables.Add(Orders);

                //Fetching Customer Data Table Data
                Console.WriteLine("Customer Table Data: ");

                //Fetching DataTable from Dataset using the Index position
                 foreach (DataRow row in dataSet.Tables[0].Rows)
                //foreach (DataRow row in dataSet.Tables["Customer"].Rows)
                {
                    //Accessing the data using string column name
                   // Console.WriteLine(row["ID"] + ",  " + row["Name"] + ",  " + row["Mobile"]);
                    //Accessing the data using integer index position
                    Console.WriteLine(row[0] + ",  " + row[1] + ",  " + row[2]);
                }
                Console.WriteLine();
                //Fetching Orders Data Table Data
                Console.WriteLine("Orders Table Data: ");
                //Fetching DataTable from the DataSet using the table name
                foreach (DataRow row in dataSet.Tables["Orders"].Rows)
                {
                    //Accessing the data using string column name
                    Console.WriteLine(row["ID"] + ",  " + row["CustomerId"] + ",  " + row["Amount"]);
                    //Accessing the data using integer index position
                    //Console.WriteLine(row[0] + ",  " + row[1] + ",  " + row[2]);
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
