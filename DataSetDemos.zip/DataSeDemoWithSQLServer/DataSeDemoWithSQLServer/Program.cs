﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace DataSeDemoWithSQLServer
{
    public class Program
    {
        static void Main(string[] args)
        {
            SqlDataAdapter daEmp;
            DataSet ds;
            DataTable dt;

            daEmp = new SqlDataAdapter("Select EmpId, EmpName, Salary from Emp", Helper.constr);

            ds = new DataSet();
            daEmp.Fill(ds, "Emp");


            foreach (DataTable tbl in ds.Tables)
            {
                Console.WriteLine("=> {0} Table:", tbl.TableName);
                for (int curCol = 0; curCol < tbl.Columns.Count; curCol++)
                {
                    Console.Write(tbl.Columns[curCol].ColumnName + "\t\t");
                }
                Console.WriteLine("\n------------------------------------------------------");
                for (int curRow = 0; curRow < tbl.Rows.Count; curRow++)
                {
                    for (int curCol = 0; curCol < tbl.Columns.Count; curCol++)
                    {
                        Console.Write(tbl.Rows[curRow][curCol].ToString() + "\t\t");
                    }
                    Console.WriteLine();
                }
            }

        }
    }
}
