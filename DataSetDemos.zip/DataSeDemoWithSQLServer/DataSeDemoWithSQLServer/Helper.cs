﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace DataSeDemoWithSQLServer
{
    public class Helper
    {
        public static string constr
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["csWave4DB"].ConnectionString;
            }
        }
    }
}
